from flask import request, jsonify
from application import app 
from application.models.dao.medicaodao import Medicaodao 
from application.models.entity.medicao import Medicao 

medicaodao = Medicaodao()
lista_medicao = medicaodao.getlistmedic()


@app.route('/')
def index():
    listaD=[]
    
    for medicoes in lista_medicao: 
        listaD.append(medicoes.todict())
    return jsonify(listaD)


@app.route('/novamedicao', methods=['POST'])
def Novamedicao():
    id=request.json["id"]
    temperatura=request.json["temperatura"]
    umidade=request.json["umidade"]
    gas=request.json["gas"]
    ozonio=request.json["ozonio"]
    Co2=request.json["Co2"]
    data=request.json["data"]    
    
    medicao = Medicao(id, temperatura, umidade, gas, ozonio, Co2, data)
    lista_medicao.append(medicao)
    return medicao.todict(), 201

