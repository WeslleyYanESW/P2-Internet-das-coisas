class Medicao:
    def __init__(self, id, temperatura, umidade, gas, ozonio, Co2, data):
        self.id = id
        self.temperatura = temperatura
        self.umidade = umidade
        self.gas = gas 
        self.ozonio = ozonio
        self.Co2 = Co2 
        self.data = data 
        
    
    def getid(self):
        return self.id
    
    def gettemperatura(self):
        return self.temperatura 
        
    def getumidade(self):
         return self.umidade 
     
    def getgas(self):
         return self.gas
     
    def getozonio(self):
         return self.ozonio 
     
    def getCo2(self):
         return self.Co2
     
    def getdata(self):
         return self.data 
     
     
    def setid(self,id):
         self.id = id
    
    def gettemperatura(self, temperatura):
         self.temperatura = temperatura 
        
    def setumidade(self, umidade):
         self.umidade = umidade  
     
    def setozonio(self, ozonio):
         self.ozonio = ozonio 
     
    def setgas(self, gas):
         self.gas = gas
         
    def setCo2(self, Co2):
         self.Co2 = Co2
     
    def setdata(self, data):
         self.data = data 
        
    def todict(self):
        return {
            "id": self.id,
            "temperatura": self.temperatura,
            "umidade": self.umidade, 
            "ozonio": self.ozonio,
            "Co2": self.Co2,
            "data": self.data  
        }
        
