from application.models.entity.medicao import Medicao

lista_medicao=[Medicao(4, 30, 9, 109, 13, 62, "21/08/2021"), Medicao(2, 24, 33, 57, 80, 15, "12/04/2021")]

class Medicaodao():
    def __init__(self):
        self.lista_medicao = lista_medicao 
        
    def getlistmedic(self):
        return self.lista_medicao
     